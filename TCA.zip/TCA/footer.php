 <?php wp_footer(); ?>
    
<?php 
    get_template_part( 'template-parts/footer/footerv1' );
?>


<script src="https://kit.fontawesome.com/3296fa4f9a.js" crossorigin="anonymous"></script>
</body>
</html>