function showmewnu()
{
    var show=document.getElementsByClassName('sub-menu');
    show[0].classList.toggle('show');
}
