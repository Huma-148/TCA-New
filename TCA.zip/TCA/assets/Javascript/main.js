function showmewnu()
{
    var show=document.getElementsByClassName('sub-menu');
    show[0].classList.toggle('show');
}

$(document).ready(function(){
    $("#primary-menu-list li").click(function(){
      $("sub-menu").toggle();
    });
  });