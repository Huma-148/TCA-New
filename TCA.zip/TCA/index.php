<?php get_header();?>
<h1 class="forest">Hello Man
    <span class="forest__row">Here it is</span>
</h1>
<?php get_footer();?>