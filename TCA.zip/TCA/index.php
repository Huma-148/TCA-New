<?php get_header();?>
<h1 class="forest">Hello Man
    <span class="forest__row">Here it is</span>
</h1>
<p><?php echo get_template_directory_uri() . '/assets/Javascript/main.js'; ?></p>
<?php get_footer();?>