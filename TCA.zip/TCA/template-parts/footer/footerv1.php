<footer class="footer">
    <div class="container">
        <!--Footer Column 1 -->
        <div class="footer__area">
        <button>
            <a href="<?php the_field('start_a_class_section_url','options'); ?>"><?php the_field('start_a_class_section','options'); ?></a>
        </button>
    
        <ul class="footer__social-media">
            <?php if(have_rows('social_media_rep','options')): 
                
                while(have_rows('social_media_rep','options')): 
                the_row(); 
                ?>
        <li><a href="<?php the_sub_field('social_media_url','options'); ?>"><?php the_sub_field('social_media_icons','options'); ?></a></li>
        <?php endwhile;
            endif;
        ?>
        
        </ul>
    
</div>
<!--Footer Column 2 -->
<div class="footer__area">
    
        <h6><?php the_field('navigate','options'); ?></h6>
        <hr>
        <div class="row">
            <div class="column">
                
        <?php
wp_nav_menu( array( 
    'theme_location' => 'footer-menu1', 
    'container'       => 'ul', 
    'menu_class' => 'footer__nav', 
    ) ); 
?>
</div>
<div class="column">
        
        <?php
wp_nav_menu( array( 
    'theme_location' => 'footer-menu2', 
    'container'       => 'ul', 
    'menu_class' => 'footer__nav', ) ); 
?>
</div>
</div>
        
    </div>
<!--Footer Column 3 -->
<div class="footer__area">
    <div class="newsletter">
<h6>Subscribe to our newsletter</h6>
<hr>
<form action="">
  <label for="email">Email Address:</label><br>
  <input type="email" id="email" name="email" value="Email Address"><br>
  <br>
  <label for="country">Country:</label><br>
  <select name="country" id="country">
  <option value="albania">Albania</option>
  <option value="algeria">Algeria</option>
  <option value="australia">Australia</option>
  <option value="belgium">Belgium</option>
</select>
  <br><br>
  <input type="submit" value="Submit">
</form> 
</div>
</div>
<div class="footer__copyright">
<hr>
<p>@<?php echo date('Y'); ?> Top Class Actions. All Rights Reserved. <a href="#">Privacy Policy</a> | <a href="#">Terms and Conditions</a></p>
</div>
    </div>  
</footer>