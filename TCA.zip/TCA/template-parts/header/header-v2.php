<div class="container main-header">
<div class="top-head">
  <div class="top-header">
     <div class="topmenu">
    <!-- navbar -->
        <?php wp_nav_menu( 
            array(
                'theme_location'=> 'topbarmenu',
            )
        );
        ?>
    </div>
  </div>
</div>
<header>
   <div class="header-main dark">
    <!-- logo -->
    <div class="logo">
      <?php if ( has_custom_logo()  ) : ?> <!--&& ! $show_title-->
		<div class="site-logo"><?php
    
              $custom_logo=wp_get_attachment_image_src(get_theme_mod('custom_logo'),'full');
             
              $logo=esc_url($custom_logo[0]);
              
           ?> 
           <img class="logo-img" src="<?php echo $logo ?>" alt="CTA Logo" height="77" width="176"/>

        </div>
	<?php endif; ?>
    </div>
    
    <div class="navmenu">
    <!-- navbar -->
    <nav id="site-navigation" class="main-navigation" role="navigation">
						<?php
						if ( has_nav_menu( 'primary' ) ) :
							wp_nav_menu(
								array(
									'theme_location' => 'primary',
									'menu_id'        => 'primary-menu',
									'walker'         => new Awps\Core\WalkerNav(),
								)
							);
						endif;
						?>
					</nav>

    </div>
   </div>
</header>
</div>