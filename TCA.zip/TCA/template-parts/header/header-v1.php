<div class="container main-header">
<div class="top-head">
  <div class="top-header">
     <div class="topmenu">
    <!-- navbar -->
        <?php wp_nav_menu( 
            array(
                'theme_location'=> 'topbarmenu',
            )
        );
        ?>
    </div>
  </div>
</div>
<header>
   <div class="header-main dark">
    <!-- logo -->
    <div class="logo">
      <?php if ( has_custom_logo()  ) : ?> <!--&& ! $show_title-->
		<div class="site-logo"><?php
    
              $custom_logo=wp_get_attachment_image_src(get_theme_mod('custom_logo'),'full');
             
              $logo=esc_url($custom_logo[0]);
              
           ?> 
           <img class="logo-img" src="<?php echo $logo ?>" alt="CTA Logo" height="77" width="176"/>

        </div>
	<?php endif; ?>
    </div>
    
    <div class="navmenu">
    <!-- navbar -->
    
        <?php wp_nav_menu( 
            array(
                'theme_location'=> 'primary',
                'menu_class'      => 'menu-wrapper',
				'container_class' => 'primary-menu-container',
				'items_wrap'      => '<ul id="primary-menu-list" >%3$s</ul>',
				'fallback_cb'     => false,
            )
        );
        ?>
    </div>
   </div>
</header>
</div>