<?php



//Addiing CSS
function AllCSS()
{
    wp_register_style( 'stylesheet', get_template_directory_uri() .'/assets/css/main.css',array(), false,'all');
    wp_enqueue_style( 'stylesheet' );
    wp_register_style( 'main-css', get_template_directory_uri() .'/style.css',array(), false,'all');
   // wp_enqueue_style( 'load-fa', 'https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css' );
    wp_enqueue_style( 'main-css' );
    wp_enqueue_script('jquery','https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js',array("jquery"),rand(111,9999),true);
    
	// Main navigation scripts.
     if ( has_nav_menu( 'primary' ) ) {
	 	wp_enqueue_script(
	 		'primary-navigation-script',
	 		get_template_directory_uri() . '/assets/Javascript/main.js',
	 		array("jquery"),
	 		1.0,
	 		true
	 	);
	 }

	 if ( has_nav_menu( 'primary' ) ) {
	 	wp_enqueue_script(
	 		'primary-navigation-script',
	 		get_template_directory_uri() . 'assets/Javascript/menu-navigation.js',
	 		array("jquery"),
			1.0,
	 		true
	 	);
	 }

}
   add_action( 'wp_enqueue_scripts' , 'AllCSS');



//Menu 
add_theme_support( 'menus');
add_theme_support( 'post-thumbnails' );
add_theme_support( 'custom-logo' );
register_nav_menus(
    array(
        'primary' => __( 'Main menu', 'theme' ),
        'topbarmenu'  => __( 'Top Bar Menu', 'theme' ),
    )
);


// Image on Post

add_image_size( 'small', 300, 300, true );
add_image_size( 'large', 800, 800, true );


//Logo size

function logo_size()
{
    $defaults = array(
        'height'      => 50,
        'width'       => 50,
        'flex-height' => true,
        'flex-width'  => true,
        'header-text' => array( 'site-title', 'site-description' ),
       'unlink-homepage-logo' => true, 
        );
        add_theme_support( 'custom-logo', $defaults );
}
add_action( 'after_setup_theme', 'logo_size' );






  function add_sub_menu_toggle( $output, $item, $depth, $args ) {
 	if ( 0 === $depth && in_array( 'menu-item-has-children', $item->classes, true ) ) {

 		// Add toggle button.
 		$output .= '<button class="sub-menu-toggle" aria-expanded="false" onClick="showmewnu()">';
	$output .= '<span class="icon-plus"><i class="fa-solid fa-angle-down"></i></span>';
 	//	$output .= '<span class="icon-minus"><i class="fa-solid fa-angle-up"></i></span>';
  	//	$output .= '<span class="screen-reader-text">' . esc_html__( 'Open menu', '' ) . '</span>';
  		$output .= '</button>';
  	}
 	return $output;
}  add_filter( 'walker_nav_menu_start_el', 'add_sub_menu_toggle', 10, 4 );