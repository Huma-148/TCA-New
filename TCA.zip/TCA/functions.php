<?php



//Addiing CSS
function AllCSS()
{
    wp_register_style( 'stylesheet', get_template_directory_uri() .'/assets/css/main.css',array(), false,'all');
    wp_enqueue_style( 'stylesheet' );
    wp_register_style( 'main-css', get_template_directory_uri() .'/style.css',array(), false,'all');
   wp_enqueue_style( 'load-fa', 'https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css' );
    wp_enqueue_style( 'main-css' );
    wp_enqueue_script('jquery','https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js',array("jquery"),rand(111,9999),true);

}
   add_action( 'wp_enqueue_scripts' , 'AllCSS');



//Menu 
add_theme_support( 'menus');
add_theme_support( 'post-thumbnails' );
add_theme_support( 'custom-logo' );
register_nav_menus(
    array(
        'primary' => __( 'Main menu', 'theme' ),
        'topbarmenu'  => __( 'Top Bar Menu', 'theme' ),
        'footer-menu1'=> __( 'Footer 1 column', 'theme' ),
        'footer-menu2'=> __( 'Footer 2 column', 'theme' ),
    )
);


// Image on Post

add_image_size( 'small', 300, 300, true );
add_image_size( 'large', 800, 800, true );


//Logo size

function logo_size()
{
    $defaults = array(
        'height'      => 50,
        'width'       => 50,
        'flex-height' => true,
        'flex-width'  => true,
        'header-text' => array( 'site-title', 'site-description' ),
       'unlink-homepage-logo' => true, 
        );
        add_theme_support( 'custom-logo', $defaults );
}
add_action( 'after_setup_theme', 'logo_size' );


